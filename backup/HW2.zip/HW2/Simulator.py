class Simulator:
	def __init__(self):
		print("");

	def loadMemory(self, path):
		print("loadMemory");
		#TODO
		
	def storeMemory(self, path):
		print("storeMemory");
		#TODO

	def	simulate(self):
		print("simulate");
		#TODO
