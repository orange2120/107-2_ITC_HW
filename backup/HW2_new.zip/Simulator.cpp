#include "Simulator.h"
#include <iostream>
#include <fstream>
using namespace std;

bool Simulator::loadMemory(string path) {
    //TODO
}
bool Simulator::storeMemory(string path) {
    //TODO
}
bool Simulator::simulate() {
    //TODO
}
