make clean
make 
./start
